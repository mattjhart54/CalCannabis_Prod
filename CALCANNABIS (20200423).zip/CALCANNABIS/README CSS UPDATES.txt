/* Remove the following */

.aca_wrapper .ACA_Content.welcome-page > table > tbody > tr > td:first-child {background-color: #162500 !important;}

/* Probably need to also remove */

.aca_wrapper .ACA_Content.welcome-page {background-color: #FFFFFF !important;}
